from app.main import app

# Definiamo `application` per ASGI
application = app
